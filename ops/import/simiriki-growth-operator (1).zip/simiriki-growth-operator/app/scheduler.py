import os
import time
import requests
from datetime import datetime

API = os.getenv("OPERATOR_URL", "http://localhost:8080")
WHATSAPP = os.getenv("WHATSAPP_WEBHOOK_URL", "")
OWNER = os.getenv("OWNER_WHATSAPP", "")
DAILY_HOUR_UTC = int(os.getenv("DAILY_HOUR_UTC", "14"))


def send_daily_kpi():
    """Fetch daily KPIs and send them via WhatsApp."""
    try:
        kpi = requests.get(f"{API}/kpi/daily", timeout=20).json()
        text = (
            f"📊 Simiriki – KPIs últimas 24h\n"
            f"Leads: {kpi['leads']}\n"
            f"Ventas: {kpi['sales']}\n"
            f"Ingresos: ${kpi['revenue']:.2f}"
        )
        if WHATSAPP:
            requests.post(WHATSAPP, json={"to": OWNER, "message": text}, timeout=15)
    except Exception:
        # Ignore errors; will try again next cycle
        pass


def main():
    """Run scheduler loop."""
    while True:
        now = datetime.utcnow()
        if now.hour == DAILY_HOUR_UTC and now.minute == 0:
            send_daily_kpi()
            # Sleep for one minute to avoid duplicate sends in the same minute
            time.sleep(60)
        time.sleep(5)


if __name__ == "__main__":
    main()