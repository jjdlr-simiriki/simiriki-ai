import os
import json
import sqlite3
import datetime as dt
from typing import Optional
import requests
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse


DB_PATH = os.getenv("DB_PATH", "data/events.db")
MP_TOKEN = os.getenv("MP_ACCESS_TOKEN", "")
CRM_WEBHOOK = os.getenv("CRM_WEBHOOK_URL", "")
WHATSAPP_WEBHOOK = os.getenv("WHATSAPP_WEBHOOK_URL", "")
OWNER_PHONE = os.getenv("OWNER_WHATSAPP", "")

app = FastAPI(title="Simiriki Growth Operator")

# Ensure the data directory exists
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
conn = sqlite3.connect(DB_PATH, check_same_thread=False)
cur = conn.cursor()

# Create tables if they don't exist
cur.execute(
    """
    CREATE TABLE IF NOT EXISTS payments(
      id TEXT PRIMARY KEY,
      status TEXT,
      description TEXT,
      email TEXT,
      amount REAL,
      currency TEXT,
      created_at TEXT
    );
    """
)
cur.execute(
    """
    CREATE TABLE IF NOT EXISTS leads(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT,
      source TEXT,
      created_at TEXT
    );
    """
)
conn.commit()


def mp_get_payment(payment_id: str) -> Optional[dict]:
    """Fetch payment details from Mercado Pago's API."""
    url = f"https://api.mercadopago.com/v1/payments/{payment_id}"
    try:
        r = requests.get(url, headers={"Authorization": f"Bearer {MP_TOKEN}"}, timeout=20)
        if r.status_code == 200:
            return r.json()
    except Exception:
        pass
    return None


def push_crm(payload: dict):
    """Send a JSON payload to your CRM webhook."""
    if not CRM_WEBHOOK:
        return
    try:
        requests.post(CRM_WEBHOOK, json=payload, timeout=15)
    except Exception:
        pass


def notify_whatsapp(text: str):
    """Send a WhatsApp message through your gateway."""
    if not WHATSAPP_WEBHOOK:
        return
    try:
        requests.post(WHATSAPP_WEBHOOK, json={"to": OWNER_PHONE, "message": text}, timeout=15)
    except Exception:
        pass


@app.get("/healthz")
async def healthz():
    """Return a simple health check."""
    return {"ok": True, "time": dt.datetime.utcnow().isoformat()}


@app.post("/webhook/mercadopago")
async def webhook_mp(req: Request):
    """
    Handle Mercado Pago webhook events. Verify the payment status
    and push data to the CRM and WhatsApp.
    """
    body = await req.json()
    action = body.get("action") or body.get("type")
    data = body.get("data", {})
    payment_id = str(data.get("id", ""))

    if not payment_id:
        return JSONResponse({"ok": True, "note": "no id"})

    payment = mp_get_payment(payment_id)
    if not payment:
        return JSONResponse({"ok": False, "error": "verify_failed"}, status_code=400)

    status = payment.get("status")
    email = (payment.get("payer") or {}).get("email")
    amount = payment.get("transaction_amount")
    currency = payment.get("currency_id")
    description = payment.get("description") or ""
    created = payment.get("date_created")

    # Persist the payment
    cur.execute(
        "REPLACE INTO payments(id,status,description,email,amount,currency,created_at) VALUES(?,?,?,?,?,?,?)",
        (payment_id, status, description, email, amount, currency, created),
    )
    conn.commit()

    # Determine tag by description
    tag = "Client – OperadorVirtual" if "Operador" in description else "Client – Sprint"

    if status == "approved":
        push_crm(
            {
                "email": email,
                "amount": amount,
                "description": description,
                "tag": tag,
                "stage": "Pago recibido",
                "source": "MercadoPago",
            }
        )
        notify_whatsapp(f"✅ Pago aprobado: {description} ${amount} – {email}")

    return {
        "ok": True,
        "status": status,
        "action": action,
        "tag": tag,
    }


@app.post("/event/lead")
async def event_lead(req: Request):
    """Record a lead event."""
    body = await req.json()
    email = body.get("email")
    source = body.get("source", "funnel")
    cur.execute(
        "INSERT INTO leads(email,source,created_at) VALUES(?,?,?)",
        (email, source, dt.datetime.utcnow().isoformat()),
    )
    conn.commit()
    return {"ok": True}


@app.get("/kpi/daily")
async def kpi_daily():
    """Return simple KPIs for the last 24 hours: leads, sales, revenue."""
    now = dt.datetime.utcnow()
    start = (now - dt.timedelta(days=1)).isoformat()
    # Approved payments in last 24h
    r = cur.execute(
        "SELECT COUNT(*), COALESCE(SUM(amount),0) FROM payments WHERE created_at>=? AND status='approved'",
        (start,),
    ).fetchone()
    sales, revenue = r[0], r[1]
    # Leads in last 24h
    l = cur.execute("SELECT COUNT(*) FROM leads WHERE created_at>=?", (start,)).fetchone()[0]
    return {
        "from": start,
        "to": now.isoformat(),
        "leads": l,
        "sales": sales,
        "revenue": revenue,
    }