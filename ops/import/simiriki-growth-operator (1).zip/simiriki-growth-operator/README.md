# Simiriki Growth Operator

This repository contains a small FastAPI service and scheduler for handling Mercado Pago payment webhooks, pushing data into your CRM (e.g. GoHighLevel), sending WhatsApp notifications, and generating daily KPI digests.

## Structure

* `app/main.py` – The FastAPI application. Provides `/webhook/mercadopago` for payment notifications, `/event/lead` for logging leads, `/kpi/daily` for metrics, and `/healthz` for a simple health check.
* `app/scheduler.py` – A simple scheduler that calls the KPI endpoint once per day and sends the summary via WhatsApp.
* `requirements.txt` – Python dependencies.
* `Dockerfile` – Build a container for the FastAPI service.
* `docker-compose.yml` – Compose file to run the operator and scheduler together.
* `.env.example` – Example environment variables. Copy to `.env` and fill in your secrets.
* `systemd/simiriki-operator.service` – Example systemd unit file for running the service on a Linux host.

## Deployment

### Docker

1. Copy `.env.example` to `.env` and fill in the variables:

   ```env
   MP_ACCESS_TOKEN=your_mercado_pago_token
   CRM_WEBHOOK_URL=https://hooks.yourcrm.com/abc
   WHATSAPP_WEBHOOK_URL=https://hooks.whatsapp-gw.local/send
   OWNER_WHATSAPP=+5218112345678
   ```

2. Start the services:

   ```bash
   docker compose up -d
   ```

3. Set the webhook in your Mercado Pago dashboard to point to `https://yourdomain.com/webhook/mercadopago`.

### Systemd

1. Place the code at `/opt/simiriki-operator`.
2. Create a `.env` file with the same variables.
3. Copy `systemd/simiriki-operator.service` to `/etc/systemd/system/`.
4. Reload systemd and start the service:

   ```bash
   sudo systemctl daemon-reload
   sudo systemctl enable --now simiriki-operator
   ```

## Usage

* **Receive payments:** Mercado Pago will call `/webhook/mercadopago` whenever a payment or subscription is updated. The service verifies the payment, stores it, and pushes an event to your CRM and WhatsApp.
* **Record leads:** Your website or ads can POST to `/event/lead` with `{ "email": "lead@example.com", "source": "ads" }` to record a new lead.
* **Daily KPIs:** Visit `/kpi/daily` or rely on the scheduler to send daily summaries.